// express/routes/qrisRoutes.js
const express = require("express");
const router = express.Router();
const multer = require("multer");
const path = require("path");
const { authenticateUser, requireAdmin, isAdmin } = require("../middlewares/auth");
const qrisController = require("../controllers/qrisController");
const rateLimit = require("express-rate-limit");

// Middleware khusus untuk rate limiting QRIS yang lebih ringan
const qrisInitLimiter = rateLimit({
  windowMs: 1 * 60 * 1000, // 1 menit
  max: 20, // Maksimum 20 request per menit
  standardHeaders: true,
  legacyHeaders: false,
  message: { error: 'Terlalu banyak permintaan ke endpoint QRIS, silakan coba lagi nanti' },
  skipSuccessfulRequests: true, // Hanya hitung permintaan yang gagal
  keyGenerator: (req) => {
    // Gunakan kombinasi IP + path + user ID (jika tersedia)
    const userId = req.userId || "";
    return req.ip + req.path + userId;
  }
});

// Middleware CORS khusus untuk QRIS
const qrisCors = (req, res, next) => {
  res.header("Access-Control-Allow-Origin", req.headers.origin || "*");
  res.header("Access-Control-Allow-Methods", "GET,POST,PUT,DELETE,OPTIONS");
  res.header(
    "Access-Control-Allow-Headers",
    "Origin, X-Requested-With, Content-Type, Accept, Authorization, Cache-Control"
  );
  res.header("Access-Control-Allow-Credentials", "true");
  
  // Tambahkan header cache-control khusus untuk QRIS
  res.header("Cache-Control", "no-store, no-cache, must-revalidate, proxy-revalidate");
  res.header("Pragma", "no-cache");
  res.header("Expires", "0");
  res.header("Surrogate-Control", "no-store");
  
  // Handle OPTIONS preflight requests
  if (req.method === "OPTIONS") {
    return res.status(200).end();
  }
  
  next();
};

// Terapkan middleware CORS khusus di semua route QRIS
router.use(qrisCors);

// Konfigurasi multer untuk upload bukti pembayaran
const storage = multer.diskStorage({
  destination: function (req, file, cb) {
    // Pastikan direktori ada
    const uploadDir = path.join(__dirname, '../uploads/payment_proof');
    require('fs').mkdirSync(uploadDir, { recursive: true });
    cb(null, uploadDir);
  },
  filename: function (req, file, cb) {
    const uniqueSuffix = Date.now() + "-" + Math.round(Math.random() * 1e9);
    const extension = path.extname(file.originalname);
    cb(null, `qris-${uniqueSuffix}${extension}`);
  }
});

const upload = multer({ 
  storage: storage,
  limits: { fileSize: 5 * 1024 * 1024 }, // 5MB
  fileFilter: function (req, file, cb) {
    const filetypes = /jpeg|jpg|png|gif|webp/; // Menambahkan dukungan untuk webp dan gif
    const mimetype = filetypes.test(file.mimetype);
    const extname = filetypes.test(path.extname(file.originalname).toLowerCase());
    
    if (mimetype && extname) {
      return cb(null, true);
    }
    cb(new Error("Hanya format .png, .jpg, .jpeg, .gif, dan .webp yang diizinkan!"));
  }
});

// Middleware upload dengan penanganan error yang lebih baik
const uploadWithErrorHandling = (req, res, next) => {
  upload.single("payment_proof")(req, res, (err) => {
    if (err) {
      if (err.code === 'LIMIT_FILE_SIZE') {
        return res.status(400).json({ 
          error: "Ukuran file terlalu besar. Maksimum 5MB." 
        });
      }
      console.error("Error upload bukti pembayaran:", err);
      return res.status(400).json({ 
        error: err.message || "Terjadi kesalahan saat mengunggah file" 
      });
    }
    next();
  });
};

// ========================
// PUBLIC ENDPOINTS
// ========================

// Endpoint publik untuk mendapatkan pengaturan QRIS
router.get("/settings/qris-public", (req, res) => {
  console.log("Public QRIS settings endpoint accessed");
  qrisController.getQrisSettings(req, res);
});

// Alias untuk kompatibilitas dengan aplikasi lama
router.get("/qris-settings/public", (req, res) => {
  console.log("Public QRIS settings endpoint (alias) accessed");
  qrisController.getQrisSettings(req, res);
});

// Endpoint publik dengan rate limit yang lebih rendah
router.get("/qris-settings", qrisInitLimiter, (req, res) => {
  console.log("QRIS settings endpoint accessed with query:", req.query);
  qrisController.getQrisSettings(req, res);
});

// Handler untuk endpoint GET /qris-payments dengan penanganan cache yang ditingkatkan
router.get("/qris-payments", authenticateUser, qrisInitLimiter, async (req, res) => {
  try {
    const user_id = req.userId;
    const limit = parseInt(req.query.limit) || 20;
    const page = parseInt(req.query.page) || 1;
    const offset = (page - 1) * limit;
    
    console.log(`Getting QRIS payments for user: ${user_id}, limit: ${limit}, page: ${page}`);
    
    // Pastikan model QrisPayment diimpor dengan benar
    const { QrisPayment, User, SubscriptionPlan } = require("../models");
    
    const payments = await QrisPayment.findAll({
      where: { user_id },
      include: [
        { model: User, attributes: ['username', 'email'] },
        { model: SubscriptionPlan, attributes: ['name', 'duration_days', 'price'] }
      ],
      order: [['createdAt', 'DESC']],
      limit,
      offset
    });
    
    const filteredPayments = payments.map(payment => {
      const paymentData = payment.toJSON();
      if (paymentData.payment_proof) {
        paymentData.has_payment_proof = true;
        delete paymentData.payment_proof;
      }
      return paymentData;
    });
    
    return res.status(200).json({
      data: filteredPayments,
      timestamp: Date.now()
    });
  } catch (error) {
    console.error("Error getting user QRIS payments:", error);
    return res.status(500).json({ error: "Server error", details: error.message });
  }
});

// ========================
// AUTHENTICATED ENDPOINTS
// ========================

// Endpoint yang memerlukan autentikasi
router.use(authenticateUser);

// User endpoints dengan rate limiting
router.post("/qris-payment", qrisInitLimiter, qrisController.createQrisPayment);
router.get("/qris-payments", qrisInitLimiter, qrisController.getUserQrisPayments);
router.post("/qris-payment/:reference/confirm-transfer", qrisInitLimiter, qrisController.confirmTransfer);

// Endpoint untuk admin dengan parameter admin=true
router.get("/admin/qris-settings", (req, res) => {
  console.log("Admin QRIS settings endpoint accessed");
  // Force admin=true untuk kompatibilitas
  req.query.admin = 'true';
  qrisController.getQrisSettings(req, res);
});

// Alias untuk kompatibilitas dengan aplikasi lama
router.get("/qris-settings/admin-true", (req, res) => {
  console.log("Admin QRIS settings endpoint (alias) accessed");
  // Force admin=true untuk kompatibilitas
  req.query.admin = 'true';
  qrisController.getQrisSettings(req, res);
});

// Endpoint untuk mendapatkan pengaturan QRIS (user biasa)
router.get("/settings/qris", (req, res) => {
  console.log("Authenticated QRIS settings endpoint accessed");
  qrisController.getQrisSettings(req, res);
});

// Retry handler untuk error 429
router.use((err, req, res, next) => {
  if (err.statusCode === 429) {
    return res.status(429).json({
      error: "Terlalu banyak permintaan. Silakan coba lagi setelah beberapa saat.",
      retryAfter: err.headers['retry-after'] || 60
    });
  }
  next(err);
});

// ========================
// ADMIN ENDPOINTS
// ========================

// Admin endpoints - membutuhkan middleware requireAdmin
router.use(requireAdmin);

// Endpoint untuk menyimpan pengaturan QRIS (admin only)
router.post("/admin/qris-settings", qrisController.saveQrisSettings);
router.post("/settings/qris", qrisController.saveQrisSettings);

router.get("/admin/qris-payments", qrisController.getAllQrisPayments);
router.put("/admin/qris-payment/:reference/verify", qrisController.verifyQrisPayment);
router.get("/admin/whatsapp-group-settings", qrisController.getWhatsAppGroupSettings);
router.post("/admin/whatsapp-group-settings", qrisController.saveWhatsAppGroupSettings);

router.post("/qris-payment/:reference/confirm", authenticateUser, async (req, res) => {
  try {
    const { reference } = req.params;
    const user_id = req.userId;
    
    // Cari pembayaran
    const { QrisPayment } = require("../models");
    
    const payment = await QrisPayment.findOne({
      where: { reference, user_id }
    });
    
    if (!payment) {
      return res.status(404).json({ error: "Pembayaran tidak ditemukan" });
    }
    
    if (payment.status !== "UNPAID") {
      return res.status(400).json({ error: "Pembayaran sudah diproses" });
    }
    
    // Update status pembayaran menjadi PENDING_VERIFICATION
    await payment.update({
      status: 'PENDING_VERIFICATION'
    });
    
    return res.json({
      success: true,
      message: "Pembayaran berhasil dikonfirmasi dan sedang menunggu verifikasi admin"
    });
  } catch (error) {
    console.error("Error konfirmasi pembayaran QRIS:", error);
    return res.status(500).json({ error: "Server error", details: error.message });
  }
});

module.exports = router;
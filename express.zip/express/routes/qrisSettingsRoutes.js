// express/routes/qrisSettingsRoutes.js

const express = require("express");
const router = express.Router();
const qrisController = require("../controllers/qrisController");
const { authenticateUser, isAdmin } = require("../middlewares/auth");

// Endpoint publik - dapat diakses tanpa autentikasi
router.get("/qris-public", (req, res) => {
  console.log("Public QRIS settings endpoint accessed");
  qrisController.getQrisSettings(req, res);
});

// Endpoint dengan parameter admin=true
router.get("/qris-settings", (req, res) => {
  console.log("QRIS settings endpoint accessed with query:", req.query);
  qrisController.getQrisSettings(req, res);
});

// Endpoint admin - memerlukan autentikasi
router.get("/admin/qris-settings", (req, res) => {
  console.log("Admin QRIS settings endpoint accessed");
  qrisController.getQrisSettings(req, res);
});

// Endpoint untuk menyimpan pengaturan (admin only)
router.post("/admin/qris-settings", authenticateUser, isAdmin, qrisController.saveQrisSettings);

router.get('/qris-public', (req, res) => {
  const { QrisSettings } = require('../models');
  // Ambil pengaturan QRIS dari database
  QrisSettings.findOne({ where: { is_active: true } })
    .then(settings => {
      if (settings) {
        res.json(settings);
      } else {
        // Jika tidak ada pengaturan, kirim nilai default
        res.json({
          merchant_name: "Kinterstore",
          qris_image: "data:image/png;base64,...", // Gambar QR default
          is_active: true,
          expiry_hours: 24,
          instructions: "Scan kode QR menggunakan aplikasi e-wallet atau mobile banking Anda."
        });
      }
    })
    .catch(err => {
      console.error("Error fetching QRIS settings:", err);
      // Tetap kirim respons default meskipun terjadi error
      res.json({
        merchant_name: "Kinterstore",
        qris_image: "data:image/png;base64,...", // Gambar QR default
        is_active: true,
        expiry_hours: 24,
        instructions: "Scan kode QR menggunakan aplikasi e-wallet atau mobile banking Anda."
      });
    });
});

module.exports = router;
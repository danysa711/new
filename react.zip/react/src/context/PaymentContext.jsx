import { createContext, useState, useContext } from "react";
import axios from "axios";
import { API_URL } from "../services/const";
import { AuthContext } from "./AuthContext";

export const PaymentContext = createContext();

export const PaymentProvider = ({ children }) => {
  const [payments, setPayments] = useState([]);
  const [loading, setLoading] = useState(false);

  const { user } = useContext(AuthContext);

  const fetchInitData = async () => {
    try {
      const res = await axios.get(`${API_URL}/api/qris-payments`, {
        params: {
          user_id: user?.id || JSON.parse(localStorage.getItem("user"))?.id,
        },
      });
      setPayments(res.data);
    } catch (err) {
      console.error("Error fetching payment data:", err);
    }
  };

  return (
    <PaymentContext.Provider value={{ payments, fetchInitData, loading }}>
      {children}
    </PaymentContext.Provider>
  );
};

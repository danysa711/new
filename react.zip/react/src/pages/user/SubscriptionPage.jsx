import React, { useState, useEffect, useContext } from 'react';
import { 
  Card, Row, Col, Typography, Button, Table, Tag, 
  Divider, Spin, Empty, Alert, message, Space 
} from 'antd';
import { ShoppingCartOutlined } from '@ant-design/icons';
import { AuthContext } from '../../context/AuthContext';
import QrisPaymentForm from '../../components/QrisPaymentForm';
import moment from 'moment';
import axiosInstance from '../../services/axios';

const { Title, Text } = Typography;

const SubscriptionPage = () => {
  const { user, updateUserData, fetchUserProfile } = useContext(AuthContext);

  const [pendingPayments, setPendingPayments] = useState([]);
  const [plans, setPlans] = useState([]);
  const [subscriptions, setSubscriptions] = useState([]);
  const [activeSubscription, setActiveSubscription] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [paymentModalVisible, setPaymentModalVisible] = useState(false);
  const [selectedPlan, setSelectedPlan] = useState(null);

  useEffect(() => {
    const fetchData = async () => {
      try {
        setLoading(true);
        setError(null);

        // Ambil daftar paket
        try {
          const plansResponse = await axiosInstance.get('/api/subscription-plans');
          setPlans(plansResponse.data);
        } catch (err) {
          console.error('Error fetching subscription plans:', err);
          setPlans([]);
        }

        // Ambil langganan user
        try {
          const subsResponse = await axiosInstance.get('/api/subscriptions/user');
          const sortedSubs = subsResponse.data.sort((a, b) => new Date(b.start_date) - new Date(a.start_date));
          setSubscriptions(sortedSubs);

          const active = subsResponse.data.find(
            (sub) => sub.status === 'active' && new Date(sub.end_date) > new Date()
          );
          setActiveSubscription(active);

          if (updateUserData) {
            if (active && !user.hasActiveSubscription) {
              updateUserData({ ...user, hasActiveSubscription: true });
            } else if (!active && user.hasActiveSubscription) {
              updateUserData({ ...user, hasActiveSubscription: false });
            }
          }
        } catch (err) {
          console.error('Error fetching user subscriptions:', err);
          setSubscriptions([]);
        }

        // Ambil pembayaran QRIS
        try {
          const userId = user?.id || JSON.parse(localStorage.getItem("user"))?.id;
          const qrisResponse = await axiosInstance.get('/api/qris-payments', {
            params: { user_id: userId }
          });

          let qrisData = qrisResponse.data?.data || qrisResponse.data || [];
          if (!Array.isArray(qrisData)) qrisData = [];

          // Filter UNPAID
          let pending = qrisData.filter((p) => p.status === 'UNPAID' || p.status === 'PENDING_VERIFICATION');

          // Hapus jika > 1 jam
          const now = new Date();
          pending = pending.filter(p => {
            const created = new Date(p.createdAt);
            const diffMinutes = (now - created) / (1000 * 60);
            return diffMinutes <= 60; // max 1 jam
          });

          // Urutkan terbaru
          pending = pending.sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt));

          // Ambil max 3
          pending = pending.slice(0, 3);

          setPendingPayments(pending);
        } catch (err) {
          console.error('Error fetching QRIS payments:', err);
          setPendingPayments([]);
        }

        setLoading(false);
      } catch (err) {
        console.error('Error fetching subscription data:', err);
        setError('Gagal memuat data langganan. Silakan coba lagi nanti.');
        setLoading(false);
      }
    };

    fetchData();
  }, [user, updateUserData]);

  const handlePurchase = (plan) => {
    setSelectedPlan(plan);
    setPaymentModalVisible(true);
  };

  const handleClosePaymentModal = () => {
    setPaymentModalVisible(false);
    setSelectedPlan(null);
    if (fetchUserProfile) fetchUserProfile();
  };

  const handleConfirmTransfer = async (record) => {
  try {
    await axiosInstance.post(`/api/qris-payment/${record.reference}/confirm-transfer`, null, {
      params: { user_id: user?.id }
    });
    message.success("Transfer dikonfirmasi, menunggu verifikasi admin");
    fetchUserProfile();
  } catch (err) {
    console.error("Confirm transfer error:", err);
    message.error("Gagal konfirmasi transfer");
  }
};

  const handleCancelOrder = async (record) => {
    try {
      await axiosInstance.delete(`/api/qris-payment/${record.reference}/cancel`, {
        params: { user_id: user?.id }
      });
      message.success("Pesanan dibatalkan");
      setPendingPayments((prev) => prev.filter(p => p.reference !== record.reference));
    } catch (err) {
      console.error("Cancel error:", err);
      message.error("Gagal membatalkan pesanan");
    }
  };

  if (loading) {
    return (
      <div style={{ textAlign: 'center', padding: '50px' }}>
        <Spin size="large" />
        <div style={{ marginTop: 20 }}>Memuat data langganan...</div>
      </div>
    );
  }

  if (error) {
    return (
      <div>
        <Title level={2}>Langganan</Title>
        <Alert message="Terjadi Kesalahan" description={error} type="error" showIcon style={{ marginBottom: 20 }} />
      </div>
    );
  }

  return (
    <div>
      <Title level={2}>Langganan</Title>

      {/* 1. Status Langganan */}
      <Card style={{ marginBottom: 24 }}>
        <Title level={4}>Status Langganan</Title>
        {activeSubscription ? (
          <Alert
            message={`Langganan aktif: ${activeSubscription.SubscriptionPlan?.name || '-'}`}
            description={`Berlaku hingga ${moment(activeSubscription.end_date).format('DD/MM/YYYY HH:mm')}`}
            type="success"
            showIcon
          />
        ) : (
          <Alert message="Belum ada langganan aktif" type="warning" showIcon />
        )}
      </Card>

      {/* 2. Paket Langganan Tersedia */}
      <div id="subscription-plans">
        <Title level={4}>Paket Langganan Tersedia</Title>
        <Row gutter={[16, 16]}>
          {plans.length > 0 ? plans.map((plan) => (
            <Col xs={24} sm={12} md={8} lg={6} key={plan.id}>
              <Card
                hoverable
                title={
                  <div style={{ display: 'flex', justifyContent: 'space-between' }}>
                    <span>{plan.name}</span>
                    <Tag color="green">Rp {parseInt(plan.price).toLocaleString('id-ID')}</Tag>
                  </div>
                }
                actions={[
                  <Button 
                    type="primary" 
                    icon={<ShoppingCartOutlined />} 
                    onClick={() => handlePurchase(plan)} 
                    block
                  >
                    Beli Sekarang
                  </Button>
                ]}
              >
                <div><Text strong>{plan.duration_days} hari</Text></div>
                <div>{plan.description || `Langganan ${plan.name}`}</div>
              </Card>
            </Col>
          )) : (
            <Col span={24}><Empty description="Belum ada paket langganan" /></Col>
          )}
        </Row>
      </div>

      {/* 3. Pembayaran Menunggu Verifikasi */}
      {pendingPayments.length > 0 && (
        <Card title={<Title level={4}>Pembayaran Menunggu Verifikasi</Title>} style={{ marginTop: 24, marginBottom: 24 }}>
          <Alert message="Pembayaran Anda sedang ditinjau" type="warning" showIcon style={{ marginBottom: 16 }} />

          <Table
            dataSource={pendingPayments}
            rowKey="reference"
            columns={[
              { title: 'Referensi', dataIndex: 'reference', render: text => <Text copyable>{text}</Text> },
              { title: 'Paket', render: (_, r) => r.SubscriptionPlan ? r.SubscriptionPlan.name : '-' },
              { title: 'Jumlah', dataIndex: 'total_amount', render: a => `Rp ${parseFloat(a).toLocaleString('id-ID')}` },
              { title: 'Tanggal', dataIndex: 'createdAt', render: d => moment(d).format('DD/MM/YYYY HH:mm') },
              { title: 'Status', key: 'status', render: (r) => <Tag color={r.payment_proof ? "processing" : "orange"}>{r.payment_proof ? "MENUNGGU VERIFIKASI" : "BELUM UPLOAD"}</Tag> },
              {
                title: 'Aksi',
  render: (record) => (
    <Space>
      {/* Tombol hanya muncul kalau belum konfirmasi transfer */}
      {record.status === "UNPAID" && (
        <Button type="primary" onClick={() => handleConfirmTransfer(record)}>
          Saya sudah transfer
        </Button>
      )}
      <Button danger onClick={() => handleCancelOrder(record)}>Batalkan</Button>
    </Space>
  )
}
            ]}
            pagination={false}
          />
        </Card>
      )}

      {/* Modal Pembayaran */}
      <Divider />
      <Card title="Riwayat Transaksi">
        <Table
          dataSource={subscriptions}
          rowKey="id"
          columns={[
            { title: 'Paket', render: (_, r) => r.SubscriptionPlan?.name || '-' },
            { title: 'Mulai', dataIndex: 'start_date', render: d => moment(d).format('DD/MM/YYYY HH:mm') },
            { title: 'Berakhir', dataIndex: 'end_date', render: d => moment(d).format('DD/MM/YYYY HH:mm') },
            { title: 'Status', dataIndex: 'status', render: s => <Tag color={s === 'active' ? 'green' : 'red'}>{s.toUpperCase()}</Tag> }
          ]}
          pagination={{ pageSize: 5 }}
        />
      </Card>

      <Card>
        <QrisPaymentForm plan={selectedPlan} visible={paymentModalVisible} onClose={handleClosePaymentModal} />
      </Card>
    </div>
  );
};

export default SubscriptionPage;
